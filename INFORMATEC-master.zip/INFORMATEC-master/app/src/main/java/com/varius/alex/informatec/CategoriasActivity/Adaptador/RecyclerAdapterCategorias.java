package com.varius.alex.informatec.CategoriasActivity.Adaptador;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import com.varius.alex.informatec.R;
import com.varius.alex.informatec.activity.Cate_1;

import java.util.ArrayList;

public class RecyclerAdapterCategorias extends RecyclerView.Adapter<RecyclerAdapterCategorias.MyViewHolder> {

    private Context context;
    private ArrayList<String> arrayList;

    public RecyclerAdapterCategorias(Context c){
        context=c;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v;
        v= LayoutInflater.from(context).inflate(R.layout.cardview_categorias,parent,false);
        final MyViewHolder viewHolder = new MyViewHolder(v);
        iniView();

        viewHolder.btn_ir_descr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IrCate_1();
            }
        });
        return viewHolder;

    }

    private void iniView() {
        arrayList = new ArrayList<>();
        arrayList.add("PROCESADORES");
        arrayList.add("CASES / ACCESORIOS");
        arrayList.add("CELULARES / TABLETS / ACCESORIOS");
        arrayList.add("CONECTIDAD / REDES");
        arrayList.add("DISCOS DUROS / ACCESORIOS");
        arrayList.add("FUENTES DE PODER");
        arrayList.add("LAPTOP / ACCESORIOS");
        arrayList.add("LICENCIAS SOFTWARE");
        arrayList.add("MEMORIAS RAM / USB / SSD");
        arrayList.add("PLACAS MADRE (MOTHERBOARDS)");
        arrayList.add("CÁMARAS WEB / VIGILANCIA");
    }

    private void IrCate_1() {
        Intent intent = new Intent(context, Cate_1.class);
        context.startActivity(intent);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
       holder.btn_ir_descr.setText(arrayList.get(position));
     }

    @Override
    public int getItemCount() {
        return 11;
    }

    class MyViewHolder extends RecyclerView.ViewHolder{

        Button btn_ir_descr;
        CardView cardview;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            cardview = itemView.findViewById(R.id.cardview_categorias);
            btn_ir_descr = itemView.findViewById(R.id.btn_ir_descr);
        }
    }



}
