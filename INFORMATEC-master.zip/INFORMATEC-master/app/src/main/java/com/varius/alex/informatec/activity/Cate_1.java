package com.varius.alex.informatec.activity;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.varius.alex.informatec.R;
import com.varius.alex.informatec.adaptador.Cate_1_Adapter;
import com.varius.alex.informatec.model.CategoriaProduct;
import com.varius.alex.informatec.utils.EspaceadoItems;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;

public class Cate_1 extends AppCompatActivity {
    private static final String PRODUCT_URL = "https://infotecutp.000webhostapp.com/selectProductos.php";
    ArrayList<CategoriaProduct> productList;
    RecyclerView recyclerView;
    private EspaceadoItems espaceadoItems;
    Button btnCategoria;
    EditText txt_minimo, txt_maximo;
    String PRODUCT_URL2 ="";
    private Cate_1_Adapter adapter,adapterBusqueda;
    private EditText campoBusqueda;
    private Button btn_mostrarTodo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cate_1);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        iniView();
        loadProducts();

        //Antiguo método de filtro de precios
        /*
        btnCategoria.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent btnCategoria = new Intent(Cate_1.this, Cate_1_filter.class );
                Bundle dato=new Bundle();
                dato.putString("cadena","https://infotecutp.000webhostapp.com/selecionFiltro.php?v1="+txt_minimo.getText().toString()+"&v2="+txt_maximo.getText().toString()+"");
                btnCategoria.putExtras(dato);
                startActivity(btnCategoria);
            }
        });*/

        //Mostrar Todos los productos
        btn_mostrarTodo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadProducts();
            }
        });



        //Filtrar producto por precio
        btnCategoria.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String precioMinimo = txt_minimo.getText().toString();
                String precioMaximo = txt_maximo.getText().toString();

                if(precioMinimo.equals("") || precioMaximo.equals("")){
                    Toast.makeText(Cate_1.this, "Por favor, llene ambos campos.", Toast.LENGTH_SHORT).show();
                } else if(Integer.parseInt(precioMinimo) >= Integer.parseInt(precioMaximo)){
                    Toast.makeText(Cate_1.this, "El rango de valores ingresado es incorrecto.", Toast.LENGTH_SHORT).show();
                } else {
                    FiltrarPrecio(precioMinimo,precioMaximo);
                }
            }
        });

        //Realizar busqueda automática cada vez que se ingrese texto en el campo
        campoBusqueda.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(charSequence.length() != 0){
                    String producto = campoBusqueda.getText().toString();
                    BuscarProducto(producto);
                } else {
                    loadProducts();
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

    }

    private void iniView() {
        btnCategoria = findViewById(R.id.btn_filtrar) ;
        btn_mostrarTodo = findViewById(R.id.btn_mostrar_todo);
        recyclerView = findViewById(R.id.recylcerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        espaceadoItems = new EspaceadoItems(30);
        recyclerView.addItemDecoration(espaceadoItems);
        productList = new ArrayList<>();
        txt_minimo = findViewById(R.id.campo_texto1);
        txt_maximo = findViewById(R.id.campo_texto2);
        campoBusqueda = findViewById(R.id.campo_busqueda);
    }

    private void loadProducts() {
        productList.clear();
        recyclerView.setAdapter(null);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, PRODUCT_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONArray array = new JSONArray(response);
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject producObjet = array.getJSONObject(i);
                                int id = producObjet.getInt("id");
                                String name = producObjet.getString("name");
                                String description = producObjet.getString("description");
                                int  price = producObjet.getInt("price");
                                int stock = producObjet.getInt("stock");
                                String img_url = producObjet.getString("img_url");
                                CategoriaProduct product = new CategoriaProduct(id, name, description, price, stock, img_url);
                                productList.add(product);
                            }
                            adapter = new Cate_1_Adapter(Cate_1.this, productList);
                            recyclerView.setAdapter(adapter);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Cate_1.this, error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
        Volley.newRequestQueue(this).add(stringRequest);
    }

    private void BuscarProducto(final String producto) {
        productList.clear();
        recyclerView.setAdapter(null);
        StringRequest buscar = new StringRequest(Request.Method.GET, PRODUCT_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONArray array = new JSONArray(response);
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject producObjet = array.getJSONObject(i);
                                int id = producObjet.getInt("id");
                                String name = producObjet.getString("name");
                                String description = producObjet.getString("description");
                                int  price = producObjet.getInt("price");
                                int stock = producObjet.getInt("stock");
                                String img_url = producObjet.getString("img_url");

                                if(name.contains(producto) || name.toLowerCase().contains(producto)){
                                    CategoriaProduct product = new CategoriaProduct(id, name, description, price, stock, img_url);
                                    productList.add(product);
                                }

                            }
                            adapterBusqueda = new Cate_1_Adapter(Cate_1.this, productList);
                            recyclerView.setAdapter(adapter);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Cate_1.this, error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
        Volley.newRequestQueue(this).add(buscar);
    }

    private void FiltrarPrecio(String minimo, String maximo) {
        productList.clear();
        recyclerView.setAdapter(null);
        final int pmin = Integer.parseInt(minimo);
        final int pmax = Integer.parseInt(maximo);

        StringRequest filtrarPrecio = new StringRequest(Request.Method.GET, PRODUCT_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONArray array = new JSONArray(response);
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject producObjet = array.getJSONObject(i);
                                int id = producObjet.getInt("id");
                                String name = producObjet.getString("name");
                                String description = producObjet.getString("description");
                                int  price = producObjet.getInt("price");
                                int stock = producObjet.getInt("stock");
                                String img_url = producObjet.getString("img_url");

                                if(price >= pmin && price <= pmax){
                                    CategoriaProduct product = new CategoriaProduct(id, name, description, price, stock, img_url);
                                    productList.add(product);
                                }

                            }
                            adapterBusqueda = new Cate_1_Adapter(Cate_1.this, productList);
                            recyclerView.setAdapter(adapter);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Cate_1.this, error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
        Volley.newRequestQueue(Cate_1.this).add(filtrarPrecio);
    }
}