package com.varius.alex.informatec.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.varius.alex.informatec.R;

public class Editar_Perfil extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_perfil);
        Button btn = (Button) findViewById(R.id.btn_cancelar);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent btn= new Intent(Editar_Perfil.this, StartActivity.class);
                startActivity(btn);
            }
        });
    }
}
