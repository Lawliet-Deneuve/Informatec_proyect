package com.varius.alex.informatec.CategoriasActivity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import com.varius.alex.informatec.CategoriasActivity.Adaptador.RecyclerAdapterCategorias;
import com.varius.alex.informatec.R;

public class CategoriasView extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RecyclerAdapterCategorias adapterCategorias;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_categorias);
        iniView();
    }

    private void iniView() {
        //Iniciando el recyclerview
        recyclerView = findViewById(R.id.lista_categorias);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        adapterCategorias = new RecyclerAdapterCategorias(this);
        recyclerView.setAdapter(adapterCategorias);
    }
}
