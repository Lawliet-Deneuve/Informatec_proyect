package com.varius.alex.informatec.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.varius.alex.informatec.R;

public class VerProductos extends AppCompatActivity {

    private String nombre,descripcion,precio,stock,url;
    private TextView txtnombre, txtdescr, txtprecio,txtstock;
    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_producto);
        GetData();
        iniView();
 }

    private void GetData() {
        nombre = getIntent().getStringExtra("nombre");
        descripcion = getIntent().getStringExtra("descripcion");
        precio = getIntent().getStringExtra("precio");
        stock = getIntent().getStringExtra("stock");
        url = getIntent().getStringExtra("url");
    }

    private void iniView() {
        txtnombre = findViewById(R.id.TextoTitulo);
        txtdescr = findViewById(R.id.textoDescripcion);
        txtprecio = findViewById(R.id.textoPrecio);
        txtstock = findViewById(R.id.textoStock);
        imageView = findViewById(R.id.imagenProducto);

        txtnombre.setText(nombre);
        txtdescr.setText(descripcion);
        txtprecio.setText(precio);
        txtstock.setText(stock);

        //Cargando imagen
        Glide.with(this)
                .load(url)
                .into(imageView);
    }


}
